package com.mdgalvis.actividaduno

import android.os.Bundle
import android.os.Handler
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.navigation.NavController
import androidx.navigation.Navigation
import java.util.*


class SecuencioramaFragment : Fragment() {
    var b_new: Button? = null
    var button1: Button? = null
    var button2: Button? = null
    var button3: Button? = null
    var button4: Button? = null
    var button5: Button? = null
    var button6: Button? = null
    var button7: Button? = null
    var button8: Button? = null
    var button9: Button? = null
    var button10: Button? = null
    var button11: Button? = null
    var button12: Button? = null
    var buttons: MutableList<Int>? = null
    var curLevel = 0
    var curGuess = 0

    lateinit var navController: NavController
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_secuenciorama, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        b_new = R.id.b_new as Button

        button1 = R.id.button1 as Button
        button2 = R.id.button2 as Button
        button3 = R.id.button3 as Button
        button4 = R.id.button4 as Button
        button5 = R.id.button5 as Button
        button6 = R.id.button6 as Button
        button7 = R.id.button7 as Button
        button8 = R.id.button8 as Button
        button9 = R.id.button9 as Button
        button10 = R.id.button10 as Button
        button11 = R.id.button11 as Button
        button12 = R.id.button12 as Button
        button1!!.tag = 1
        button2!!.tag = 2
        button3!!.tag = 3
        button4!!.tag = 4
        button5!!.tag = 5
        button6!!.tag = 6
        button7!!.tag = 7
        button8!!.tag = 8
        button9!!.tag = 9
        button10!!.tag = 10
        button11!!.tag = 11
        button12!!.tag = 12
        disableButtons()
        buttons = ArrayList()
        (buttons as ArrayList<Int>).add(1)
        (buttons as ArrayList<Int>).add(2)
        (buttons as ArrayList<Int>).add(3)
        (buttons as ArrayList<Int>).add(4)
        (buttons as ArrayList<Int>).add(5)
        (buttons as ArrayList<Int>).add(6)
        (buttons as ArrayList<Int>).add(7)
        (buttons as ArrayList<Int>).add(8)
        (buttons as ArrayList<Int>).add(9)
        (buttons as ArrayList<Int>).add(10)
        (buttons as ArrayList<Int>).add(11)
        (buttons as ArrayList<Int>).add(12)
        b_new!!.setOnClickListener {
            b_new!!.visibility = View.INVISIBLE
            curGuess = 0
            curLevel = 1
            generateButtons(curLevel)
        }
        button1!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button2!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button3!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button4!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button5!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button6!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button7!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button8!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button9!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button10!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button11!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
        button12!!.setOnClickListener { v ->
            buttonLogic(v)
            (v as Button).text = "O"
        }
    }

    private fun buttonLogic(v: View) {
        val tempList: MutableList<Int> = ArrayList()
        for (i in 0 until curLevel) {
            tempList.add(buttons!![i])
        }
        if (tempList.contains(v.tag)) {
            curGuess++
            checkWin()
        } else {
            lostGame()
        }
    }

    private fun checkWin() {
        if (curGuess == curLevel) {
            disableButtons()
            if (curLevel == 12) {
                Toast.makeText(activity, "Success!", Toast.LENGTH_SHORT).show()
                b_new!!.visibility = View.VISIBLE
            } else {
                Handler().postDelayed({
                    curGuess = 0
                    curLevel++
                    generateButtons(curLevel)
                }, 1000)
            }
        }
    }

    private fun lostGame() {
        Toast.makeText(activity, "Fail!", Toast.LENGTH_SHORT).show()
        disableButtons()
        b_new!!.visibility = View.VISIBLE
    }

    private fun generateButtons(number: Int) {
        button1!!.text = ""
        button2!!.text = ""
        button3!!.text = ""
        button4!!.text = ""
        button5!!.text = ""
        button6!!.text = ""
        button7!!.text = ""
        button8!!.text = ""
        button9!!.text = ""
        button10!!.text = ""
        button11!!.text = ""
        button12!!.text = ""
        Collections.shuffle(buttons)
        for (i in 0 until number) {
            showButton(buttons!![i])
        }
        Handler().postDelayed({
            button1!!.text = ""
            button2!!.text = ""
            button3!!.text = ""
            button4!!.text = ""
            button5!!.text = ""
            button6!!.text = ""
            button7!!.text = ""
            button8!!.text = ""
            button9!!.text = ""
            button10!!.text = ""
            button11!!.text = ""
            button12!!.text = ""
            enableButtons()
        }, 1000)
    }

    private fun showButton(number: Int) {
        when (number) {
            1 -> button1!!.text = "O"
            2 -> button2!!.text = "O"
            3 -> button3!!.text = "O"
            4 -> button4!!.text = "O"
            5 -> button5!!.text = "O"
            6 -> button6!!.text = "O"
            7 -> button7!!.text = "O"
            8 -> button8!!.text = "O"
            9 -> button9!!.text = "O"
            10 -> button10!!.text = "O"
            11 -> button11!!.text = "O"
            12 -> button12!!.text = "O"
        }
    }

    private fun enableButtons() {
        button1!!.isEnabled = true
        button2!!.isEnabled = true
        button3!!.isEnabled = true
        button4!!.isEnabled = true
        button5!!.isEnabled = true
        button6!!.isEnabled = true
        button7!!.isEnabled = true
        button8!!.isEnabled = true
        button9!!.isEnabled = true
        button10!!.isEnabled = true
        button11!!.isEnabled = true
        button12!!.isEnabled = true
    }

    private fun disableButtons() {
        button1!!.isEnabled = false
        button2!!.isEnabled = false
        button3!!.isEnabled = false
        button4!!.isEnabled = false
        button5!!.isEnabled = false
        button6!!.isEnabled = false
        button7!!.isEnabled = false
        button8!!.isEnabled = false
        button9!!.isEnabled = false
        button10!!.isEnabled = false
        button11!!.isEnabled = false
        button12!!.isEnabled = false
    }

}


